# Iris-JPN
Emerging Technologies Problem Sheet 3 - Using Iris data set with Jupyter, Pyplot and Numpy.
